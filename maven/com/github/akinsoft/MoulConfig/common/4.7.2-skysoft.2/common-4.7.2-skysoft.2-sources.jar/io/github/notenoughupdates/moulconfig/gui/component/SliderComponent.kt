package io.github.notenoughupdates.moulconfig.gui.component

import io.github.notenoughupdates.moulconfig.GuiTextures
import io.github.notenoughupdates.moulconfig.gui.GuiComponent
import io.github.notenoughupdates.moulconfig.gui.GuiImmediateContext
import io.github.notenoughupdates.moulconfig.gui.MouseEvent
import io.github.notenoughupdates.moulconfig.observer.GetSetter
import kotlin.math.max
import kotlin.math.min

open class SliderComponent(
    val value: GetSetter<Float>,
    val minValue: Float,
    val maxValue: Float,
    val minStep: Float,
    private val width: Int,
) : GuiComponent() {
    var clicked: Boolean = false
    override fun getWidth(): Int {
        return width
    }

    override fun getHeight(): Int {
        return 16
    }

    override fun render(context: GuiImmediateContext) {
        if (clicked) {
            setValueFromContext(context)
        }
        val value: Float = value.get()
        context.renderContext.drawTexturedRect(GuiTextures.SLIDER_ON_CAP, 0F, 0F, 4F, context.height.toFloat())
        context.renderContext.drawTexturedRect(GuiTextures.SLIDER_OFF_CAP, (context.width - 4).toFloat(), 0F, 4F, context.height.toFloat())
        val sliderPosition = ((value.coerceIn(minValue..maxValue) - minValue) / (maxValue - minValue) * context.width).toInt()
        if (sliderPosition > 5) {
            context.renderContext.drawTexturedRect(GuiTextures.SLIDER_ON_SEGMENT, 4F, 0F, (sliderPosition - 4).toFloat(), context.height.toFloat())
        }
        if (sliderPosition < context.width - 5) {
            context.renderContext.drawTexturedRect(
                GuiTextures.SLIDER_OFF_SEGMENT,
                sliderPosition.toFloat(),
                0F,
                (context.width - 4 - sliderPosition).toFloat(),
                context.height.toFloat()
            )
        }
        for (i in 0..3) {
            val notchX = context.width * i / 4 - 1
            context.renderContext.drawTexturedRect(
                if (notchX > sliderPosition) GuiTextures.SLIDER_OFF_NOTCH else GuiTextures.SLIDER_ON_NOTCH,
                notchX.toFloat(), (context.height - 4) / 2F, 2F, 4F
            )
        }
        context.renderContext.drawTexturedRect(
            GuiTextures.SLIDER_BUTTON,
            (sliderPosition - 4).toFloat(), 0F, 8F, context.height.toFloat()
        )
    }

    open fun setValueFromContext(context: GuiImmediateContext) {
        var v: Float = context.mouseX * (maxValue - minValue) / context.width + minValue
        v = min(v.toDouble(), maxValue.toDouble()).toFloat()
        v = max(v.toDouble(), minValue.toDouble()).toFloat()
        v = Math.round(v / minStep) * minStep
        value.set(v)
    }

    override fun mouseEvent(mouseEvent: MouseEvent, context: GuiImmediateContext): Boolean {
        if (!context.renderContext.isMouseButtonDown(0)) clicked = false
        if (context.isHovered && mouseEvent is MouseEvent.Click && mouseEvent.mouseState && mouseEvent.mouseButton == 0) {
            clicked = true
        }
        if (clicked) {
            setValueFromContext(context)
            return true
        }
        return false
    }
}
